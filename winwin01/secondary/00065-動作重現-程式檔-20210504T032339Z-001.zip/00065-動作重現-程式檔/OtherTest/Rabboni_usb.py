#%%
#20201216 Tang
# -*- coding: UTF-8 -*-
# coding=Big5   #UTF-8  #Big5   #看檔案儲存時選哪種編碼; 編碼 先寫先贏 (coding 必須寫在前兩列)
from rabboni import*
import time, sys
import random
print("Connecting....")
rabbo = Rabboni(mode = "USB") #先宣告一個物件
rabbo.connect()#連結上rabboni，若沒插上會報錯
print("Status(0->unconnected,1->connected):",rabbo.Status) ##1表有連接上 0代表沒連接上

rabbo.set_sensor_config(acc_scale = 16, gyr_scale = 250,rate = 10,threshold=1000000000) 
##設定Rabboni sensor數值

rabbo.read_data()#讀取資料 必跑
try:
    while True:#一直打印資料 直到結束程式
        rabbo.print_data()#print資料        
        time.sleep(1)
        
       #  if rabbo.Cnt == 100://20201203
       #     rabbo.rst_count()//20201203
except KeyboardInterrupt:#在terminal下按Ctrl+C 結束程式
    print('Shut done!')
    print (rabbo.Accx_list)#印出到結束程式時的所有Accx值
    rabbo.stop()#停止dongle
    rabbo.write_csv(data = rabbo.Accx_list,file_name ="AccX")#將Accx寫出csv檔
    rabbo.write_csv(data = rabbo.Accy_list,file_name ="AccY")#將AccY寫出csv檔
    rabbo.write_csv(data = rabbo.Accz_list,file_name ="AccZ")#將AccZ寫出csv檔
    rabbo.write_csv(data = rabbo.Gyrx_list,file_name ="GyrX")#將Gyrx寫出csv檔
    rabbo.write_csv(data = rabbo.Gyry_list,file_name ="GyrY")#將Gyry寫出csv檔
    rabbo.write_csv(data = rabbo.Gyrz_list,file_name ="GyrZ")#將Gyrz寫出csv檔
    print(f'data_count={rabbo.data_num}')
    #rabbo.plot_pic(data = rabbo.Accx_list,file_name = "AccX",show = True)#將Accx畫出圖案並存檔
finally:
    rabbo.stop()

# %%
