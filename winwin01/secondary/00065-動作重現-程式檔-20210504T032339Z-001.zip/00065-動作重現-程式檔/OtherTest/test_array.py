
import numpy as np 


# inputA = np.array([1, 2, 3, 4])
# inputB = np.array([2, 4])
# inputC = np.dot(inputA, inputB)


inputA = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
inputB = [1, 1]
inputC = []

for i in range(len(inputA)-len(inputB)):
    Sumproduct = 0
    for j in range(len(inputB)):
        # print(inputA[i])
        # print(inputA[i+j])
        # print(inputB[j])
        Sumproduct += inputA[i+j] * inputB[j]
    inputC.append(Sumproduct)

print(inputA)
print(inputB)
print(inputC)