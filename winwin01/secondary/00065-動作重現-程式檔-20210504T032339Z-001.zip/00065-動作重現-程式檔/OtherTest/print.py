#!/usr/bin/env python3
# so that script can be run from Brickman

a = 1
print(a)