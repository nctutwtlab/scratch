## testBLE.py
# -*- coding: UTF-8 -*-
# coding=Big5   #UTF-8  #Big5   #看檔案儲存時選哪種編碼; 編碼 先寫先贏 (coding 必須寫在前兩列)
from rabboni import*
import time, sys

rabbo = Rabboni(mode = "USB") #先宣告一個物件
rabbo.connect()#連結上rabboni，若沒插上會報錯
print("Status(0->unconnected,1->connected):",rabbo.Status) ##1表有連接上 0代表沒連接上

rabbo.set_sensor_config(acc_scale = 2, gyr_scale = 250, rate = 20, threshold=10) 
##設定Rabboni sensor數值
## max. acc =2g , 加速度上限2g
## max. gyr =250deg/sec, 角速度上限 250度/秒
## sampling rate = 10/20/50Hz, rabboni sampling rate = 20, 超過50不支援
## threshold 超過3軸平方相加, 超過threshold值的話, Current_Count會+1, 如果設很小, Current_Count會一直累加

#time.sleep(1)  # 等 3 秒讓你看 :-)
outputFile = "data.txt"
fout = open(outputFile,'w')

idx = 0
freq = 0.1 ##PC每0.1s抓一次rabboni數值, downsampling 2x
N = 200 ##200點約20s
fout.write(f"##Sampling_Rate {1/freq}Hz Sampling_Time {freq}sec Total_Time {freq*N}sec\n")
fout.write("##AccX AccY AccZ GryX GryY GryZ Current_Cnt Store_Cnt\n")
rabbo.read_data()#讀取資料 必跑
print("擷取倒數開始, 請保持靜止")

for CountDown in range(3,0,-1):
    print(f"開始擷取倒數{CountDown}秒")
    for i in range(10):
        data = f"{rabbo.Accx} {rabbo.Accy} {rabbo.Accz} {rabbo.Gyrx} {rabbo.Gyry} {rabbo.Gyrz} {rabbo.Cur_Cnt} {rabbo.Store_Cnt}\n"
        if rabbo.Accz == 0: 
            ##如果Rabboni讀出數值0, 跳過不存
            continue
        else:
            fout.write(data)
        ##把數列的前面用初始狀態填滿
    time.sleep(1)

try:
    while True:#一直打印資料 直到結束程式
        if idx > N:
            break
        
        idx += 1
        start = time.time()
        while True:
            end = time.time()
            if(end-start > freq):
                break
        #rabbo.print_data()#print資料
        data = f"{rabbo.Accx} {rabbo.Accy} {rabbo.Accz} {rabbo.Gyrx} {rabbo.Gyry} {rabbo.Gyrz} {rabbo.Cur_Cnt} {rabbo.Store_Cnt}\n"
        fout.write(data)
        #print("ax",rabbo.Accx)
        #print("ay",rabbo.Accy)
        #print("az",rabbo.Accz)
        #print("gx",rabbo.Gyrx)
        #print("gy",rabbo.Gyry)
        #print("gz",rabbo.Gyrz)
        print(f"{round(idx*freq,1)}秒")
        #print("Current_Count",rabbo.Cur_Cnt)
        #print("Store_Count",rabbo.Store_Cnt)
        
        #rabbo.print_data()#print資料   
    fout.close()    
        
        
       #  if rabbo.Cnt == 100://20201203
       #     rabbo.rst_count()//20201203
except KeyboardInterrupt:#結束程式
    print('Shut done!')
    # print(rabbo.Accx_list)#印出到結束程式時的所有Accx值
    rabbo.stop()#停止dongle
    # rabbo.write_csv(data = rabbo.Accx_list,file_name ="AccX")#將Accx寫出csv檔
    # rabbo.plot_pic(data = rabbo.Accx_list,file_name = "AccX",show = True)#將Accx畫出圖案並存檔
finally:
    rabbo.stop()