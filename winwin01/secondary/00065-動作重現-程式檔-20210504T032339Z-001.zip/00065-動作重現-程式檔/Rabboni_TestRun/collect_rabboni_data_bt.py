### testBLE.py
# -*- coding: UTF-8 -*-
# coding=Big5   #UTF-8  #Big5   #看檔案儲存時選哪種編碼; 編碼 先寫先贏 (coding 必須寫在前兩列)
from rabboni import*
import time, sys
try:
   rabbo = Rabboni(mode="BLE") #先宣告一個物件
   rabbo.scan() #掃描所有藍芽Device
except Exception as e:
   print(e)
   print("可能你沒把 Rabboni 藍芽開啟或 Rabboni 沒電了 !")
   print("也可能缺 BLED112 驅動程式, 或 Dongle 忘了插入!")
   print("參考 http://www.picaxe.com/BLED112-Bluetooth-USB-Dongle/")
   sys.exit( )
rabbo.print_device() # 列出所有藍芽Device
print("====== 以上是掃描到的 BLE MAC =====")
#rabbo.connect("D6:42:7C:0B:37:59")#依照MAC連接
rabbo.connect("D4:97:48:50:4D:28")#依照MAC連接
#rabbo.connect("D8:C2:AE:3F:07:06")#依照MAC連接
#rabbo.connect("D6:C0:8D:22:8A:EE")#依照MAC連接
#rabbo.connect("C7:5F:1E:EA:3F:05")#依照MAC連接
#rabbo.connect("D7:C7:D6:87:99:17")#依照MAC連接
#rabbo.connect("FA:93:A6:F7:4F:1B")#依照MAC連接
#rabbo.connect("FC:9A:74:9E:52:5C")  #依照MAC連接
rabbo.discover_characteristics()#掃描所有服務 可略過
rabbo.print_char()#列出所有服務 可略過
time.sleep(1)  # 等 3 秒讓你看 :-)
rabbo.read_data()#讀取資料 必跑
outputFile = "data.txt"
fout = open(outputFile,'w')
idx = 0
freq = 0.05
N = 100
try:
    while True:#一直打印資料 直到結束程式
        if idx > N:
            break
        
        idx += 1
        start = time.time()
        while True:
            end = time.time()
            if(end-start > freq):
                break
        #rabbo.print_data()#print資料
        data = f"{rabbo.Accx} {rabbo.Accy} {rabbo.Accz} {rabbo.Gyrx} {rabbo.Gyry} {rabbo.Gyrz}\n"
        fout.write(data)
        print("ax",rabbo.Accx)
        print("ay",rabbo.Accy)
        print("az",rabbo.Accz)
        print("gx",rabbo.Gyrx)
        print("gy",rabbo.Gyry)
        print("gz",rabbo.Gyrz)
    fout.close()    
        
        
       #  if rabbo.Cnt == 100://20201203
       #     rabbo.rst_count()//20201203
except KeyboardInterrupt:#結束程式
    print('Shut done!')
    print(rabbo.Accx_list)#印出到結束程式時的所有Accx值
    rabbo.stop()#停止dongle
    rabbo.write_csv(data = rabbo.Accx_list,file_name ="AccX")#將Accx寫出csv檔
    rabbo.plot_pic(data = rabbo.Accx_list,file_name = "AccX",show = True)#將Accx畫出圖案並存檔
finally:
    rabbo.stop()