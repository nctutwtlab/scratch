import sys
class Data:
    def __init__(self, data):
        self.ax = data[0]
        self.ay = data[1]
        self.az = data[2]
        #self.gx = data[3]
        #self.gy = data[4]
        #self.gz = data[5]
        #self.CR = data[6]
        #self.TR = data[7]

inputFile = 'Cross_Vel_Output.txt'
fin = open(inputFile, 'r')
lines = fin.readlines()
data = list()
for line in lines:
    ss = line.strip().split()
    d = Data(ss)
    data.append(d)

print(len(data))

#sys.exit()
for d in data:
    #print(d.ax, d.ay, d.az)
    print(d.ax, d.az)
    #print(d.gx, d.gy, d.gz)