#!/usr/bin/env python3
# so that script can be run from Brickman

#from ev3dev.ev3 import *
from ev3dev2.motor import MediumMotor, LargeMotor
from ev3dev2.motor import SpeedDPS, SpeedRPM, SpeedRPS, SpeedDPM
from time import sleep

m = MediumMotor('outA')
#m2 = LargeMotor('outB')


m.on_for_seconds(speed=SpeedDPS(300), seconds=1)
m.on_for_seconds(speed=SpeedDPS(-300), seconds=1)
m.on_for_seconds(speed=SpeedDPS(600), seconds=1)
m.on_for_seconds(speed=SpeedDPS(-600), seconds=1)

'''
m2.run_to_rel_pos(position_sp=270, speed_sp=100, stop_action="hold")
sleep(2.5)
m.run_to_rel_pos(position_sp=200, speed_sp=100, stop_action="hold")
sleep(2)
m2.run_to_rel_pos(position_sp=-270, speed_sp=100, stop_action="hold")
sleep(2.5)
m.run_to_rel_pos(position_sp=-200, speed_sp=100, stop_action="hold")
sleep(2)
'''

'''
for i in range(50,300,50):
    m.run_timed(time_sp=500, speed_sp=-i)
    sleep(1)   # Give the motor time to move
#m.run_timed(time_sp=500, speed_sp=-720)
#sleep(0.2)
#m.run_timed(time_sp=500, speed_sp=-360)
#sleep(0.2)
#m.run_timed(time_sp=500, speed_sp=360)
#sleep(0.2)
#m.run_timed(time_sp=500, speed_sp=720)
#sleep(0.2)
sleep(5)

#from ev3dev2.sound import Sound

#print("Finding BT controller...")
#devices = [evdev.InputDevice(fn) for fn in evdev.list_devices()]
#for device in devices:
#    print('Hello, test!')

#sound = Sound()
#sound.speak('Welcome to the E V 3 dev project!')
#print('Hello, my name is ev3!')
'''