## testBLE.py
# -*- coding: UTF-8 -*-
# coding=Big5   #UTF-8  #Big5   #看檔案儲存時選哪種編碼; 編碼 先寫先贏 (coding 必須寫在前兩列)
from rabboni import *
import time, sys

rabbo = Rabboni(mode = "USB") #先宣告一個物件
rabbo.connect()#連結上rabboni，若沒插上會報錯
print("Status(0->unconnected,1->connected):",rabbo.Status) ##1表有連接上 0代表沒連接上

rabbo.set_sensor_config(acc_scale = 2, gyr_scale = 250, rate = 20, threshold=10) 
##設定Rabboni sensor數值
## max. acc =2g , 加速度上限2g
## max. gyr =250deg/sec, 角速度上限 250度/秒
## sampling rate = 10/20/50Hz, rabboni sampling rate = 20, 超過50不支援
## threshold 超過3軸平方相加, 超過threshold值的話, Current_Count會+1, 如果設很小, Current_Count會一直累加

#time.sleep(1)  # 等 3 秒讓你看 :-)
outputFile = "data.txt"
fout = open(outputFile,'w')

idx = 0
time_step = 0.1 ##PC每0.1s抓一次rabboni數值, downsampling 2x
N = 60 ##50點約5s
AccX = []
AccY = []
AccZ = []
VelX = [0]
VelY = [0]
VelZ = [0]
fout.write(f"##Sampling_Rate {1/time_step}Hz Sampling_Time {time_step}sec Total_Time {time_step*N}sec\n")
fout.write("##AccX AccY AccZ GryX GryY GryZ Current_Cnt Store_Cnt\n")
rabbo.read_data()#讀取資料 必跑
print("擷取倒數開始, 請保持靜止")

for CountDown in range(5,0,-1):
    print(f"開始擷取倒數{CountDown}秒, 請維持靜止")
    for i in range(3):
        data = f"{rabbo.Accx} {rabbo.Accy} {rabbo.Accz} {rabbo.Gyrx} {rabbo.Gyry} {rabbo.Gyrz} {rabbo.Cur_Cnt} {rabbo.Store_Cnt}\n"
        if rabbo.Accz == 0: 
            ##如果Rabboni讀出數值0, 跳過不存
            continue
        else:           
            #fout.write(data)
            #AccX.append(rabbo.Accx)
            #AccY.append(rabbo.Accy)
            #AccZ.append(rabbo.Accz)
            continue
        ##把數列的前面用初始狀態填滿
    time.sleep(1)

print(f"1秒後開始移動")

try:
    while True:#一直打印資料 直到結束程式
        if idx > N:
            break
        
        idx += 1
        start = time.time()
        while True:
            end = time.time()
            if(end-start > time_step):
                break
        #rabbo.print_data()#print資料
        data = f"{rabbo.Accx} {rabbo.Accy} {rabbo.Accz} {rabbo.Gyrx} {rabbo.Gyry} {rabbo.Gyrz} {rabbo.Cur_Cnt} {rabbo.Store_Cnt}\n"
        fout.write(data)
        AccX.append(rabbo.Accx)
        AccY.append(rabbo.Accy)
        AccZ.append(rabbo.Accz)
        #print("ax",rabbo.Accx)
        #print("ay",rabbo.Accy)
        #print("az",rabbo.Accz)
        #print("gx",rabbo.Gyrx)
        #print("gy",rabbo.Gyry)
        #print("gz",rabbo.Gyrz)
        print(f"{round(idx*time_step,1)}秒")
        #print("Current_Count",rabbo.Cur_Cnt)
        #print("Store_Count",rabbo.Store_Cnt)
        
        #rabbo.print_data()#print資料   
    fout.close()    
        
        
       #  if rabbo.Cnt == 100://20201203
       #     rabbo.rst_count()//20201203
except KeyboardInterrupt:#結束程式
    print('Shut done!')
    # print(rabbo.Accx_list)#印出到結束程式時的所有Accx值
    rabbo.stop()#停止dongle
    # rabbo.write_csv(data = rabbo.Accx_list,file_name ="AccX")#將Accx寫出csv檔
    # rabbo.plot_pic(data = rabbo.Accx_list,file_name = "AccX",show = True)#將Accx畫出圖案並存檔
finally:
    rabbo.stop()

#####資料分析#####
# FIR = [-0.003030338, -0.018614165, -0.050304518, -0.073910029, -0.053372462, -0.004817135, -0.008282124,
#      -0.093456584, -0.141541022, -0.005882332, 0.25654488, 0.393325249, 0.25654488,
#      -0.005882332, -0.141541022, -0.093456584, -0.008282124, -0.004817135, -0.053372462,
#      -0.073910029, -0.050304518, -0.018614165, -0.003030338]

FIR = [-0.3220567277543708,
    0.062152373216767,
    -0.11011859987054366,
    -0.16425642545708966,
    0.5342873316739037,
    0.5342873316739037,
    -0.16425642545708966,
    -0.11011859987054366,
    0.062152373216767,
    -0.3220567277543708]

AccX_FIR=[]
AccY_FIR=[]
AccZ_FIR=[]

for i in range(len(AccX)-len(FIR)):
    Sumproduct_AccX = 0
    Sumproduct_AccY = 0
    Sumproduct_AccZ = 0
    for j in range(len(FIR)):
        Sumproduct_AccX += AccX[i+j] * FIR[j]
        Sumproduct_AccY += AccY[i+j] * FIR[j]
        Sumproduct_AccZ += AccZ[i+j] * FIR[j]
    AccX_FIR.append(Sumproduct_AccX)
    VelX.append(VelX[-1]+Sumproduct_AccX*time_step)
    AccY_FIR.append(Sumproduct_AccY)
    VelY.append(VelY[-1]+Sumproduct_AccY*time_step)
    AccZ_FIR.append(Sumproduct_AccZ)
    VelZ.append(VelZ[-1]+Sumproduct_AccZ*time_step)

#for i in range(floor(len(AccX_FIR)/10)):
    

##存檔紀錄AccX/Y/Z_FIR####
fout = open("Output_Vel.txt",'w')
fout.write(f"##Sampling_Rate {1/time_step}Hz Sampling_Time {time_step}sec Total_Time {time_step*N}sec\n")
fout.write("##VelX VelY VelZ\n")
for i in range(len(AccX_FIR)):
    fout.write(f"{VelX[i]} {VelY[i]} {VelZ[i]}\n")
fout.close()


fout = open("Output_Acc.txt",'w')
fout.write(f"##Sampling_Rate {1/time_step}Hz Sampling_Time {time_step}sec Total_Time {time_step*N}sec\n")
fout.write("##AccX AccY AccZ\n")
for i in range(len(AccX_FIR)):
    fout.write(f"{AccX[i]} {AccY[i]} {AccZ[i]}\n")
fout.close()

fout = open("Output_Acc_FIR.txt",'w')
fout.write(f"##Sampling_Rate {1/time_step}Hz Sampling_Time {time_step}sec Total_Time {time_step*N}sec\n")
fout.write("##AccX_FIR AccY_FIR AccZ_FIR\n")
for i in range(len(AccX_FIR)):
    fout.write(f"{AccX_FIR[i]} {AccY_FIR[i]} {AccZ_FIR[i]}\n")
fout.close()


fout = open("Output_Acc_all.txt",'w')
#fout.write(f"##Sampling_Rate {1/time_step}Hz Sampling_Time {time_step}sec Total_Time {time_step*N}sec\n")
fout.write("##AccX AccY AccZ AccX_FIR AccY_FIR AccZ_FIR VelX VelY VelZ\n")
for i in range(len(AccX_FIR)):
    fout.write(f"{AccX[i]} {AccY[i]} {AccZ[i]} {AccX_FIR[i]} {AccY_FIR[i]} {AccZ_FIR[i]} {VelX[i]} {VelY[i]} {VelZ[i]}\n")
fout.close()

#########################
